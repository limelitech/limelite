<?php
$conn = mysqli_connect('localhost', 'root', '', 'db_page_content');
$sql = "SELECT * FROM pages WHERE id = ?";
$statement = $conn->prepare($sql);
$statement->bind_param("i", $_REQUEST['id']);
$statement->execute();
$result = $statement->get_result();
if (!empty($result)) {
    while ($row = $result->fetch_assoc()) {
?>
        <h3><?php echo $row['title']; ?></h3>
        <div><?php echo $row['content']; ?></div>
<?php
    }
}
?>