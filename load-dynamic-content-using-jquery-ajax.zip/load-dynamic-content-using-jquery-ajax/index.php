<?php
$conn = mysqli_connect('localhost', 'root', '', 'db_page_content');
$sql = "SELECT * FROM pages";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();
?>
<html>
<head>
<title>Load Dynamic Content using jQuery AJAX</title>
<meta name="viewport" content="width=device-width , initial-scale=1.0">
<script src="https://code.jquery.com/jquery-3.6.1.min.js"
	integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ="
	crossorigin="anonymous"></script>
<script type="text/javascript" src="content.js"></script>
<style type="text/css" media="screen">
body {
	width: 610;
	font-family: arial;
}

#menu {
	background: #f6f7f9;
	border-top: #D1D0D0 1px solid;
	border-bottom: #D1D0D0 1px solid;
}

#menu input[type="button"] {
	margin-left: 4px;
	padding: 13px 15px;
	border: 0px;
	background-color: #D1D0D0;
	cursor: pointer;
}

#output {
	min-height: 300px;
	border: #F0F0F0 1px solid;
	padding: 15px;
}

#menu input[type="button"].active {
	background: #232323;
	color: #FFF;
}

@media screen and (max-width: 700px) {
	body {
		width: auto;
	}
}
</style>
</head>
<body>
<?php
if (! empty($result)) {
    ?>
<div id="menu">
<?php
    while ($row = $result->fetch_assoc()) {
        ?>
        <input class="page-menu" type="button"
			value="<?php echo $row["title"];  ?>"
			onClick="getPage(<?php echo $row["id"]; ?>,this);" />
            <?php
    }
    ?>
</div>
<?php
}
?>
<div id="output"></div>
</body>
</html>