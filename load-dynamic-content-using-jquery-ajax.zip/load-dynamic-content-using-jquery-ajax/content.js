function getPage(id,obj) {
	$(".page-menu").removeClass("active");
	$('#output').html('<img class="loader" src="loader.gif" />');
	jQuery.ajax({
		url: "get-content-ajax.php",
		data: 'id=' + id,
		type: "POST",
		success: function(data) { 
			$(obj).addClass("active");
			$('#output').html(data); 
		}
	});
}

$(document).ready(function() {
	getPage(1, $(".page-menu:first-child"));
});
